import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import plot_tree

# Load dataset
df = pd.read_csv("scaled.csv")  

# Separate features and target variable
X = df.drop(columns=['num'])  # 'num' is the target variable
y = df['num']  

# Split data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Save training data for reference
train_data = X_train.copy()
train_data['target'] = y_train
train_data.to_csv("train_data.csv", index=False)

# Save testing data for reference
test_data = X_test.copy()
test_data['target'] = y_test
test_data.to_csv("test_data.csv", index=False)

# Train a Random Forest model
rf_model = RandomForestClassifier(n_estimators=8, random_state=42)  
rf_model.fit(X_train, y_train)

# Extract a single decision tree from the Random Forest
tree_model = rf_model.estimators_[0]  

# Identify features used in the decision tree
used_features = set(X.columns[i] for i in tree_model.tree_.feature if i != -2)  # -2 indicates a leaf node

# Save visualization data
visualization_data = X_train[list(used_features)].copy()
visualization_data['target'] = y_train
visualization_data.to_csv("visualization.csv", index=False)

# Plot decision tree
plt.figure(figsize=(15, 10))
plot_tree(tree_model, feature_names=X.columns, 
          class_names=[str(c) for c in sorted(y.unique())],  # Fix class_names
          filled=True)
plt.title("Decision Tree from Random Forest")
plt.show()
